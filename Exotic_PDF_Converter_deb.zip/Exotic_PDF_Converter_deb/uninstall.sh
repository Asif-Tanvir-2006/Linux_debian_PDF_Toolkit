echo "Removing Exotic PDF Converter....."
sudo rm -rf ~/.Exotic_pdf_residing_directory
sudo rm -rf ~/.Exotic_PDF_Converter
sudo rm /usr/share/applications/Exotic_PDF_Converter.desktop
sudo rm /opt/icon_exotic_pdf.png
sudo rm /opt/runner_exotic_pdf.sh
echo "exiting....."
