#!/bin/bash
cd ~/.Exotic_pdf_residing_directory
source exotic_pdf_dependencies/bin/activate
python3 ~/.Exotic_pdf_residing_directory/.data_program/PDF_Toolkit_Linux_By_Asif.py
