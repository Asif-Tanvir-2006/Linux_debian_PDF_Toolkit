#!/bin/bash
echo "Initiating..."
chmod +x uninstall.sh
# echo "Updating the database..."
# sudo apt update
# clear
# echo "Update check finished..."
echo "Making directories..."
mkdir ~/.Exotic_pdf_residing_directory
export PATH="$HOME/.Exotic_pdf_residing_directory:$PATH"
sudo cp .data_program/icon_exotic_pdf.png /opt
sudo cp .data_program/runner_exotic_pdf.sh /opt
sudo mv .data_program ~/.Exotic_pdf_residing_directory/
sudo mv ~/.Exotic_pdf_residing_directory/.data_program/Exotic_PDF_Converter.txt /usr/share/applications/Exotic_PDF_Converter.desktop
# mv ~/.Exotic_pdf_residing_directory/.data_program/runner.sh ~/.Exotic_pdf_residing_directory
echo "Installing dependencies..."
sudo apt-get install libreoffice
sudo apt-get install ghostscript
sudo apt-get install python3
sudo apt-get install python3-pip
sudo pip install virtualenv -t ~/.Exotic_pdf_residing_directory
cd ~/.Exotic_pdf_residing_directory
virtualenv exotic_pdf_dependencies
source exotic_pdf_dependencies/bin/activate
echo "Installing modules..."
pip install kivy kivymd img2pdf pdf2image PyPDF2
echo "Making executables"
sudo chmod +x /opt/runner_exotic_pdf.sh
chmod +x /usr/share/applications/Exotic_PDF_Converter.desktop
echo "Exiting..."

